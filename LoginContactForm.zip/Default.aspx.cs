﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source =.,Inital Catalog = Login; Integrateed Security = True;");
        SqlDataAdapter sda = new SqlDataAdapter("Select count(*) From Log_Table Where Username = '" + txtUsername.Text + "' and Password='" + txtPassword.Text + "'",con);
        DataTable dt = new DataTable();
        sda.Fill(dt);

        if (dt.Rows[0][0].ToString() == "1")
        {
            Response.Redirect("Default2.aspx");
        }
        else
        {
            Label1.Visible = true;
        }
    }

}
