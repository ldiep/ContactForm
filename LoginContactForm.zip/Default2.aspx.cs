﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;

public partial class Default2 : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {

            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress("ldiep20@gmail.com");
            mailMessage.To.Add("ldiep20@gmail.com");
            mailMessage.Subject = txtSubject.Text;

            mailMessage.Body = "<b>Sender's Name: </b>" + txtName.Text + "<br/>"
                   + "<b>Sender's Email: </b>" + txtEmail.Text + "<br/>"
                   + "<b>Sender's Message: </b>" + txtMessage.Text;
            mailMessage.IsBodyHtml = true;

            SmtpClient smtpClient =
                new SmtpClient("smtp.sendgrid.net", 587);
            smtpClient.EnableSsl = true;
            smtpClient.Credentials =
                new System.Net.NetworkCredential("ldiep20", "Contactform1");
            smtpClient.Send(mailMessage);

            Label1.ForeColor = System.Drawing.Color.Blue;
            Label1.Text = "Form submitted successfully";

            txtName.Enabled = false;
            txtEmail.Enabled = false;
            txtSubject.Enabled = false;
            txtMessage.Enabled = false;
            Button1.Enabled = false;
        }
        catch (Exception ex)
        {
            // Log - Unsuccessful
            Label1.ForeColor = System.Drawing.Color.Blue;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "An error occured, please try again";
        }

    }
}
